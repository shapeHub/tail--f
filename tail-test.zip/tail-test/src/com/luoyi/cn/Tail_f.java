package com.luoyi.cn;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

import org.junit.Test;
/**
 * 
 * @author Administrator
 * 算法设计：
 * 获取文件长度作为偏移量，从文件末端往回一行一行读，
 * 每读一行便用StringBuilder拼接到字符串首端，方便顺序输出
 * 直到读到十行或者文件读取完结束
 * 返回拼接好的字符串
 */
public class Tail_f {
	
	public static StringBuilder readFileFromEnd(String filename) {
	    RandomAccessFile rf = null;
	    try {
	        rf = new RandomAccessFile(filename, "r"); //文件io流
	        long fileLength = rf.length();   //文件长度
	        long start = rf.getFilePointer();// 返回此文件中的当前偏移量
	        long readIndex = start + fileLength -1;
	        String line;
	        rf.seek(readIndex);// 设置偏移量为文件末尾
	        int c = -1;
	        int result = 0;
	        StringBuilder bs = new StringBuilder();  //用于保存
	        while (readIndex > start) {
	            c = rf.read();
	            String readText = null;
	            if (c == '\n' || c == '\r') {//如果读取有换行符
	                line = rf.readLine();  //读取一行
	                if (line != null) {
	                    readText = new String(line.getBytes("ISO-8859-1"), "UTF8");
	                }
	                readIndex--;
	            }
	            readIndex--;
	            rf.seek(readIndex);
	            if (readIndex == 0) {// 当文件指针退至文件开始处，输出第一行
	                readText = rf.readLine();
	                bs = bs.insert(0, readText+"\n");
	                break;
	            }
	            if (readText != null) {
	                bs = bs.insert(0, readText+"\n");
	                result++;
	            }
	            if(result==10)break;  //默认为10行
	        }
	        
	      return bs;
	    } catch (FileNotFoundException e) {
	        e.printStackTrace();
	    } catch (IOException e) {
	        e.printStackTrace();
	    } finally {
	        try {
	            if (rf != null)
	                rf.close();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
		return null;
		
	}
	
}
