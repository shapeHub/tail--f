package com.luoyi.cn;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.RandomAccessFile;

import org.junit.Test;
/**
 * 
 * @author Administrator
 * 算法设计：
 * 
 * 获取文件长度作为偏移量，从文件末端往回一行一行读，
 * 每读一行便用StringBuilder拼接到字符串首端，方便顺序输出
 * 直到读到10行或者文件读取完结束
 * 返回拼接好的字符串
 * 监听文件长度是否变化，如果变化则进入读取
 */
public class Tail_f {

	
	public static StringBuilder readFileFromEnd2(String filename,int lineLen) {
		long fileLength = 0;
		
		while(true){
			File file = new File(filename);
			long fileLen = file.length();
			//System.out.println("---------------"+fileLen);
			try {
				Thread.sleep(1000); //间隔一秒再输出
			} catch (InterruptedException e1) {
				// TODO 自动生成的 catch 块
				e1.printStackTrace();
			} 
			while(fileLen!=fileLength){
				System.out.println("更新进入:");
				 RandomAccessFile rf = null;
				    try {
				        rf = new RandomAccessFile(filename, "r"); //文件io流
				        fileLength = rf.length();   //文件长度
				        long start = rf.getFilePointer();// 返回此文件中的当前偏移量
				        long readIndex = start + fileLength -1;
				        //System.out.println("---------------"+fileLength);
				        String line;
				        rf.seek(readIndex);// 设置偏移量为文件末尾
				        int c = -1;
				        int result = 0;
				        StringBuilder bs = new StringBuilder();  //用于保存
				        while (readIndex > start) {
				            c = rf.read();
				            String readText = null;
				            if (c == '\n' || c == '\r') {//如果读取有换行符
				                line = rf.readLine();  //读取一行
				                if (line != null) {
				                    readText = new String(line.getBytes("ISO-8859-1"), "UTF8");
				                }
				               readIndex--;  //防止两次进入此if语句
				            }
				            readIndex--;
				            rf.seek(readIndex);
				            if (readIndex == 0) {// 当文件指针退至文件开始处，读取第一行
			 	                readText = rf.readLine();
			 	                bs = bs.insert(0, readText+"\n"); 
			 	                break;
			 	            }
				            if (readText != null) {
				            	 
				                bs = bs.insert(0, readText+"\n");
				                result++;
				            }
				            if(result==lineLen)break;  //默认为10行
				        }
				        System.out.println(bs);
				        //return bs;
				    } catch (FileNotFoundException e) {
				        e.printStackTrace();
				    } catch (IOException e) {
				        e.printStackTrace();
				    } finally {
				        try {
				            if (rf != null)
				                rf.close();
				        } catch (IOException e) {
				            e.printStackTrace();
				        }
				    }
				  
			}
		}
	   
		
	}
	
}
