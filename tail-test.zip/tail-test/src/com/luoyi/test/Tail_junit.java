package com.luoyi.test;

import org.junit.Test;

import com.luoyi.cn.Tail_f;
//单元测试
public class Tail_junit {

	@Test
	public void test() throws InterruptedException {
		StringBuilder arrs = Tail_f.readFileFromEnd2("test.log",10);//参数为文件名
		System.out.println(arrs);
	}
	
	//@Test
	public void test3() {
		StringBuilder arrs = Tail_f.readFileFromEnd2("text.log",50);//参数为文件名
		System.out.println(arrs);
	}

}
