package com.luoyi.test;

import org.junit.Test;

import com.luoyi.cn.Tail_f;
//单元测试
public class Tail_junit {

	//@Test
	public void test() {
		StringBuilder arrs = Tail_f.readFileFromEnd("test.log");//参数为文件名
		System.out.println(arrs);
	}
	//@Test
	public void test2() {
		StringBuilder arrs = Tail_f.readFileFromEnd("text.log");//参数为文件名
		System.out.println(arrs);
	}
	@Test
	public void test3() {
		StringBuilder arrs = Tail_f.readFileFromEnd("text.log");//参数为文件名
		System.out.println(arrs);
	}

}
